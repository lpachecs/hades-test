# HomeController: Snapshot Management
lorum